//
//  ViewController.h
//  Restrictions Cracker
//
//  Created by Sterling  on 1/10/2016.
//  Copyright © 2016 TheHitherGuy. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (strong) NSMutableDictionary *dictionary;
@property NSMutableSet *set;
@property (assign) IBOutlet NSButton *button2;
-(void)doi;
- (NSData *)doSHA1MD5:(NSData *)dataIn;
@end

