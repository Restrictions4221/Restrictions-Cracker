//
//  Restrict.m
//  Restrictions Cracker
//
//  Created by Sterling  on 1/10/2016.
//  Copyright © 2016 TheHitherGuy. All rights reserved.
//

#import "Restrict.h"

@implementation Restrict

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
