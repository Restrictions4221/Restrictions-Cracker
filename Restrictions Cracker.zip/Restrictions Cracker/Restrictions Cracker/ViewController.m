//
//  ViewController.m
//  Restrictions Cracker
//
//  Created by Sterling  on 1/10/2016.
//  Copyright © 2016 TheHitherGuy. All rights reserved.
//
//#import <RNCryptor/RNCryptor.h>
#import "ShellTask.h"
#import "Restrict.h"
#import "ViewController.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonHMAC.h>
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonKeyDerivation.h>

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    /*NSString *home = NSHomeDirectory();
    for (NSString *string in [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup/25118b6343bff6980dbf1ba5f42c53e2071f63c1"] error:NULL]) {
        for (NSString *string2 in [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup/25118b6343bff6980dbf1ba5f42c53e2071f63c1"] stringByAppendingString:[NSString stringWithFormat:@"/%@",string]] error:NULL]) {
            NSString *string3 = [ShellTask executeShellCommandSynchronously:[NSString stringWithFormat:@"plutil -p %@",[self terminalString:[[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup/25118b6343bff6980dbf1ba5f42c53e2071f63c1"] stringByAppendingString:[NSString stringWithFormat:@"/%@/%@",string,string2]]]]];
            if ([string3 containsString:@": Unexpected character"]) {
                
            } else {
                [string3 writeToFile:[NSString stringWithFormat:@"/Users/sterling/Desktop/Back/%@",string2] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
            }
        }
    }*/
    //NSData *data = [self doSHA1MD5:[@"hello" dataUsingEncoding:NSUTF8StringEncoding]];
    
    //NSLog(@"%@,%@",[NSData AES]);
    // NSLog(@"%@",string2);
        // Do any additional setup after loading the view.
}
///Read file using Open Panel.
- (IBAction)readUsingSavePanel:(id)sender {
    NSOpenPanel * zOpenPanel = [NSOpenPanel openPanel];
    //NSArray * zAryOfExtensions = [NSArray arrayWithObjects:@"png",@"jpg",nil];
    //[zOpenPanel setAllowedFileTypes:zAryOfExtensions];
    NSInteger zIntResult = [zOpenPanel runModal];
    if (zIntResult == NSFileHandlingPanelCancelButton) {
        NSLog(@"readUsingOpenPanel cancelled");
        return;
    }
    NSURL *zUrl = [zOpenPanel URL];
    //NSData *s = [[NSData alloc] initWithContentsOfFile:[zUrl path]];
    
    //window.contentViewController = datr;
    //[win showWindow:self];
    [@"#!/usr/bin/env perl\nuse Crypt::PBKDF2;\n\nif (@ARGV < 2) {   \n   print \"[!] Error: please specify hash (first argument) and salt (second argument)\\n\";\n   exit (1); \n} \nmy $match = pack (\"H*\", $ARGV[0]); # TODO: check if it is of length 40 \nmy $salt  = pack (\"H*\", $ARGV[1]); # of length 8? \nmy $iter  = 1000; \nmy $pbkdf2 = Crypt::PBKDF2->new (hash_class => 'HMACSHA1', iterations => $iter);\nmy $num;\nfor ($num = 0; $num < 10000; $num++) {\n   my $pass = sprintf (\"%04d\", $num);\n   my $hash = $pbkdf2->PBKDF2 ($salt, $pass);\n   if ($match eq $hash) {\n      printf (\"%s:%s:%s:%s\\n\", unpack (\"H*\", $hash), unpack (\"H*\", $salt), $iter, $pass);\n      exit (0);\n   }\n}\nexit (1);" writeToFile:@"/tmp/ios7.pl" atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    NSString *string = [ShellTask executeShellCommandSynchronously:[NSString stringWithFormat:@"plutil -p %@",[self terminalString:zUrl.path]]];
    //NSString *string = [NSString stringWithContentsOfFile:[_dictionary objectForKey:sender.displayname] encoding:NSUTF8StringEncoding error:NULL];
    
    string = [[[[[[string stringByReplacingOccurrencesOfString:@"{\n  \"RestrictionsPasswordKey\" => " withString:@""] stringByReplacingOccurrencesOfString:@"\n  \"RestrictionsPasswordSalt\" =>" withString:@""] stringByReplacingOccurrencesOfString:@"\n}" withString:@""] stringByReplacingOccurrencesOfString:@" " withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""] stringByReplacingOccurrencesOfString:@"<" withString:@""];
    NSLog(@"%@",string);
    NSDictionary *arrat = @{@"keyer":[string substringToIndex:40],@"salter":[[string substringFromIndex:40] stringByReplacingOccurrencesOfString:@"\n" withString:@""]};
    //NSArray *array = [string componentsSeparatedByString:@" "];
    //NSMutableDictionary *dict;
    //for ()
    /*if ([[arrat objectAtIndex:0] length] > [[arrat objectAtIndex:1] length]) {
     [dict setValue:[arrat objectAtIndex:0] forKey:@"keyer"];
     [dict setValue:[arrat objectAtIndex:1] forKey:@"salter"];
     } else {
     [dict setValue:[arrat objectAtIndex:1] forKey:@"keyer"];
     [dict setValue:[arrat objectAtIndex:0] forKey:@"salter"];
     }*/
    
    //c3165d9d915ec19e85f16259a8150f3d6071277c:31b4fa25:1000:8354
    NSInteger ie = NSClosableWindowMask | NSTitledWindowMask;
    
    NSWindow *windo = [[NSWindow alloc] initWithContentRect:NSMakeRect(200, 200, 205,25) styleMask:ie backing:NSBackingStoreBuffered defer:NO];
    //windo.titleVisibility = NSWindowTitleHidden;
    //windo.titlebarAppearsTransparent = YES;
    //windo.styleMask |= NSFullSizeContentViewWindowMask;
    NSWindowController *win = [[NSWindowController alloc] initWithWindow:windo];
    //[window shows]
    //NSViewController *view = [[NSViewController alloc] init];
    //windo.contentViewController = view;
    NSTextField *text = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 0, 205, 25)];
    //NSString *stringy = [self random2:20];
    //text.identifier = stringy;
    text.selectable = YES;
    text.stringValue = @"Cracking... Please wait...";
    text.editable = NO;
    //text.st
    //[_set addObject:text];
    //text.stringValue = @"Please wait. This may take a while.";
    windo.contentView = text;
    //[win.contentViewController loadView];
    //[win windowWillLoad];
    //[windo.contentView setAppearance:[NSAppearance appearanceNamed:@"neq"]];
    //win.contentViewController = [[NSViewController alloc] initWithNibName:@"Empty" bundle:nil];
    //win.contentViewController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialController];
    [win showWindow:self];
    [self performSelectorInBackground:@selector(restricti:) withObject:[NSSet setWithObjects:arrat, text, nil]];
    //datr.imageview.image = [[NSImage alloc] initWithData:s];
    //_image.image = [[NSImage alloc] initWithData:s];
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}
-(void)doi {
    NSMutableSet *set = [[NSMutableSet alloc] init];
    for (NSView *view3 in self.view.subviews) {
        [set addObject:view3];
    }
    if (set.count > 0) {
    for (NSView *i in set) {
        [i removeFromSuperview];
    }
    }
    _dictionary = [[NSMutableDictionary alloc] init];
    int x = 0;
    int y = 0;
    NSString *home = NSHomeDirectory();
    NSArray *array = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup"] error:NULL];
    //NSLog(@"%@",array);
    for (NSString *string in array) {
        
        NSDictionary *dict = [[NSDictionary alloc] initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@/Info.plist",[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup"],string]];
        if ([[dict valueForKey:@"Device Name"] isEqualToString:@".DS_Store"] != YES) {
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/%@/Info.plist",[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup"],string]]) {
                //NSLog(@"%@",dict);
                //BOOL y;
                //if (array.count > (self.view.bounds.size.width / 10)) {
                //y = YES;
                int h = ((self.view.bounds.size.width / 30) * (30 - y)) - 30;
                Restrict *button = [[Restrict alloc] initWithFrame:NSMakeRect((self.view.frame.size.width / 4 * x), h, self.view.frame.size.width / 4, 30)];
                button.title = [dict valueForKey:@"Device Name"];
                button.displayname = [dict valueForKey:@"Display Name"];
                
                button.target = self;
                button.bordered = YES;
                button.bezelStyle = NSRegularSquareBezelStyle;
                button.action = @selector(restrictionBreak:);
                if ([[[[[dict valueForKey:@"Product Version"] stringByReplacingOccurrencesOfString:@"." withString:@""] stringByReplacingOccurrencesOfString:@"G" withString:@""] stringByReplacingOccurrencesOfString:@"M" withString:@""] intValue] >= 1000) {
                    [_dictionary setObject:[NSString stringWithFormat:@"%@/%@/39/398bc9c2aeeab4cb0c12ada0f52eea12cf14f40b",[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup"],string] forKey:[dict valueForKey:@"Display Name"]];
                    
                } else {
                    [_dictionary setObject:[NSString stringWithFormat:@"%@/%@/398bc9c2aeeab4cb0c12ada0f52eea12cf14f40b",[home stringByAppendingString:@"/Library/Application Support/MobileSync/Backup"],string] forKey:[dict valueForKey:@"Display Name"]];
                }
                [self.view addSubview:button];
                x = x + 1;
                if (x > 4) {
                    x = 0;
                    y = y + 1;
                }
            }
        }
        
        //}
        
    }

}


-(void)restrictionBreak:(Restrict*)sender {
    /*  {
     
     "RestrictionsPasswordKey" => <c3165d9d 915ec19e 85f16259 a8150f3d 6071277c>
     "RestrictionsPasswordSalt"=> <31b4fa25>
     }*/
    [@"#!/usr/bin/env perl\nuse Crypt::PBKDF2;\n\nif (@ARGV < 2) {   \n   print \"Error:Not Valid\\n\";\n   exit (1); \n} \nmy $match = pack (\"H*\", $ARGV[0]); # TODO: check if it is of length 40 \nmy $salt  = pack (\"H*\", $ARGV[1]); # of length 8? \nmy $iter  = 1000; \nmy $pbkdf2 = Crypt::PBKDF2->new (hash_class => 'HMACSHA1', iterations => $iter);\nmy $num;\nfor ($num = 0; $num < 10000; $num++) {\n   my $pass = sprintf (\"%04d\", $num);\n   my $hash = $pbkdf2->PBKDF2 ($salt, $pass);\n   if ($match eq $hash) {\n      printf (\"%s:%s:%s:%s\\n\", unpack (\"H*\", $hash), unpack (\"H*\", $salt), $iter, $pass);\n      exit (0);\n   }\n}\nexit (1);" writeToFile:@"/tmp/ios7.pl" atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    NSString *string = [ShellTask executeShellCommandSynchronously:[NSString stringWithFormat:@"plutil -p %@",[self terminalString:[_dictionary objectForKey:sender.displayname]]]];
    //NSString *string = [NSString stringWithContentsOfFile:[_dictionary objectForKey:sender.displayname] encoding:NSUTF8StringEncoding error:NULL];
    
    string = [[[[[[string stringByReplacingOccurrencesOfString:@"{\n  \"RestrictionsPasswordKey\" => " withString:@""] stringByReplacingOccurrencesOfString:@"\n  \"RestrictionsPasswordSalt\" =>" withString:@""] stringByReplacingOccurrencesOfString:@"\n}" withString:@""] stringByReplacingOccurrencesOfString:@" " withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""] stringByReplacingOccurrencesOfString:@"<" withString:@""];
    NSLog(@"%@",string);
    NSDictionary *arrat = @{@"keyer":[string substringToIndex:40],@"salter":[[string substringFromIndex:40] stringByReplacingOccurrencesOfString:@"\n" withString:@""]};
    //NSArray *array = [string componentsSeparatedByString:@" "];
    //NSMutableDictionary *dict;
    //for ()
    /*if ([[arrat objectAtIndex:0] length] > [[arrat objectAtIndex:1] length]) {
        [dict setValue:[arrat objectAtIndex:0] forKey:@"keyer"];
        [dict setValue:[arrat objectAtIndex:1] forKey:@"salter"];
    } else {
        [dict setValue:[arrat objectAtIndex:1] forKey:@"keyer"];
        [dict setValue:[arrat objectAtIndex:0] forKey:@"salter"];
    }*/
    
    //c3165d9d915ec19e85f16259a8150f3d6071277c:31b4fa25:1000:8354
    NSInteger i = NSClosableWindowMask | NSTitledWindowMask;
    
    NSWindow *windo = [[NSWindow alloc] initWithContentRect:NSMakeRect(200, 200, 205,25) styleMask:i backing:NSBackingStoreBuffered defer:NO];
    //windo.titleVisibility = NSWindowTitleHidden;
    //windo.titlebarAppearsTransparent = YES;
    //windo.styleMask |= NSFullSizeContentViewWindowMask;
    NSWindowController *win = [[NSWindowController alloc] initWithWindow:windo];
    //[window shows]
    //NSViewController *view = [[NSViewController alloc] init];
    //windo.contentViewController = view;
    NSTextField *text = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 0, 205, 25)];
    //NSString *stringy = [self random2:20];
    //text.identifier = stringy;
    text.selectable = YES;
    text.stringValue = @"Cracking... Please wait...";
    text.editable = NO;
    //text.st
    //[_set addObject:text];
    //text.stringValue = @"Please wait. This may take a while.";
    windo.contentView = text;
    //[win.contentViewController loadView];
    //[win windowWillLoad];
    //[windo.contentView setAppearance:[NSAppearance appearanceNamed:@"neq"]];
    //win.contentViewController = [[NSViewController alloc] initWithNibName:@"Empty" bundle:nil];
    //win.contentViewController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialController];
    [win showWindow:self];
    [self performSelectorInBackground:@selector(restricti:) withObject:[NSSet setWithObjects:arrat, text, nil]];
    //[self restricti:[NSSet setWithObjects:arrat, text, nil]];
    
    
    
}


// ===================




-(void)restricti:(NSSet*)set {
    NSDictionary *arrat = nil;
    NSTextField *string = nil;
    for (id i in set) {
        if ([i class] == NSClassFromString(@"NSDictionary")) {
            arrat = i;
        }
        if ([i class] == NSClassFromString(@"__NSDictionaryI")) {
            arrat = i;
        }
        if ([i class] == NSClassFromString(@"NSTextField")) {
            string = i;
        }
    }
    NSString *string2 = [ShellTask executeShellCommandSynchronously:[NSString stringWithFormat:@"perl /tmp/ios7.pl %@ %@",[arrat objectForKey:@"keyer"],[arrat objectForKey:@"salter"]]];
    string2 = [string2 stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@:%@:1000:",[arrat objectForKey:@"keyer"],[arrat objectForKey:@"salter"]] withString:@""];
    string2 = [string2 stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@:%@:10000:",[arrat objectForKey:@"keyer"],[arrat objectForKey:@"salter"]] withString:@""];
    string2 = [string2 stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@:%@:100:",[arrat objectForKey:@"keyer"],[arrat objectForKey:@"salter"]] withString:@""];
    string2 = [string2 stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@:%@:10:",[arrat objectForKey:@"keyer"],[arrat objectForKey:@"salter"]] withString:@""];
    string2 = [string2 stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@:%@:1:",[arrat objectForKey:@"keyer"],[arrat objectForKey:@"salter"]] withString:@""];
    if ([string2 containsString:@"filedoesnotexistorisnotreadableorisnotaregularfile(ErrorDomain=NSCocoaErrorDomainCode=260\"Thefile“398bc9c2aeeab4cb0c12ada0f52eea12cf14f40b”couldn’tbeopenedbecausethereisnosuchfile.\"UserInfo={NSFilePath="]) {
        string.stringValue = @"Sorry, this is a jailbroken iDevice.";
    } else {
        if ([string2 containsString:@"Error:Not Valid"]) {
            string.stringValue = @"Not a valid file";
        } else {
            if ([string2 isEqualToString:@""]) {
                string.stringValue = @"Not a valid file";
            } else {
            string.stringValue = [NSString stringWithFormat:@"Password: %@",string2];
        NSLog(@"%@",string2);
            }
        }
    }
    //[[NSApplication sharedApplication] set]
    
}


-(NSString*)terminalString:(NSString*)string {
    string = [string stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
    NSLog(@"%@",string);
    return string;
    
}





-(IBAction)startDownloader:(NSButton*)sender {
    //[ShellTask e]
    //NSString *string = [ShellTask executeShellCommandSynchronously:@"cpan install Crypt::PBKDF2"];
    sender.stringValue = @"Downloading & Installing";
    NSString *string = [ShellTask executeShellCommandSynchronously:@"cpan install Crypt::PBKDF2"];
    [@"YES" writeToFile:[[self applicationDirectoryPath] stringByAppendingString:@"/Text.txt"] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    
    NSLog(@"%@",string);
    NSInteger i = NSClosableWindowMask | NSTitledWindowMask | NSMiniaturizableWindowMask | NSResizableWindowMask;
    
    NSWindow *windo = [[NSWindow alloc] initWithContentRect:NSMakeRect(200, 200, 205,25) styleMask:i backing:NSBackingStoreBuffered defer:NO];
    //windo.titleVisibility = NSWindowTitleHidden;
    //windo.titlebarAppearsTransparent = YES;
    //windo.styleMask |= NSFullSizeContentViewWindowMask;
    NSWindowController *win = [[NSWindowController alloc] initWithWindow:windo];
    //[window shows]
    //NSViewController *view = [[NSViewController alloc] init];
    //windo.contentViewController = view;
    //NSView *view = [[NSView alloc] initW]
    ViewController *view = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateControllerWithIdentifier:@"Doi"];
    windo.title = @"Restrictions Cracker";
    win.contentViewController = view;
    [view doi];
    //[win.contentViewController loadView];
    //[win windowWillLoad];
    //[windo.contentView setAppearance:[NSAppearance appearanceNamed:@"neq"]];
    //win.contentViewController = [[NSViewController alloc] initWithNibName:@"Empty" bundle:nil];
    //win.contentViewController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialController];
    [win showWindow:self];
    [self.view.window close];

    
    //[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"Done"];
    //NSLog(@"%@",string);
}
- (NSString*)applicationDirectoryPath {
    NSString* bundleID = [[NSBundle mainBundle] bundleIdentifier];
    NSFileManager*fm = [NSFileManager defaultManager];
    NSURL*    dirPath = nil;
    
    // Find the application support directory in the home directory.
    NSArray* appSupportDir = [fm URLsForDirectory:NSApplicationSupportDirectory
                                        inDomains:NSUserDomainMask];
    if ([appSupportDir count] > 0)
    {
        // Append the bundle ID to the URL for the
        // Application Support directory
        dirPath = [[appSupportDir objectAtIndex:0] URLByAppendingPathComponent:bundleID];
        
        // If the directory does not exist, this method creates it.
        // This method is only available in OS X v10.7 and iOS 5.0 or later.
        NSError*    theError = nil;
        if (![fm createDirectoryAtURL:dirPath withIntermediateDirectories:YES
                           attributes:nil error:&theError])
        {
            // Handle the error.
            
            return nil;
        }
    }
    
    return dirPath.path;
}

@end
