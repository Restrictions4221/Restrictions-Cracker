//
//  ViewController2.m
//  Restrictions Cracker
//
//  Created by Sterling  on 1/10/2016.
//  Copyright © 2016 TheHitherGuy. All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 ()

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

@end
