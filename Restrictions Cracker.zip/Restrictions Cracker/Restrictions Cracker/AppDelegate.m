//
//  AppDelegate.m
//  Restrictions Cracker
//
//  Created by Sterling  on 1/10/2016.
//  Copyright © 2016 TheHitherGuy. All rights reserved.
//

#import "AppDelegate.h"
#import "ShellTask.h"
#import "ViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    //NSNib *nib = [[NSNib alloc] initWithNibNamed:@"HitherWindow" bundle:nil];
    NSString *h = [NSString stringWithContentsOfFile:[[self applicationDirectoryPath] stringByAppendingString:@"/Text.txt"] encoding:NSUTF8StringEncoding error:NULL];
    if ([h isEqualToString:@"YES"] != YES) {
    NSInteger i = NSClosableWindowMask | NSTitledWindowMask | NSMiniaturizableWindowMask | NSResizableWindowMask;
    
    NSWindow *windo = [[NSWindow alloc] initWithContentRect:NSMakeRect(200, 200, 205,25) styleMask:i backing:NSBackingStoreBuffered defer:NO];
    //windo.titleVisibility = NSWindowTitleHidden;
    //windo.titlebarAppearsTransparent = YES;
    //windo.styleMask |= NSFullSizeContentViewWindowMask;
    NSWindowController *win = [[NSWindowController alloc] initWithWindow:windo];
    //[window shows]
    //NSViewController *view = [[NSViewController alloc] init];
    //windo.contentViewController = view;
    //NSView *view = [[NSView alloc] initW]
        ViewController *view = [[ViewController alloc] initWithNibName:@"ViewController2" bundle:nil];
        view.button2.action = @selector(startDownloader);
        view.button2.target = self;
        
        win.contentViewController = view;
    //[win windowWillLoad];
    //[windo.contentView setAppearance:[NSAppearance appearanceNamed:@"neq"]];
    //win.contentViewController = [[NSViewController alloc] initWithNibName:@"Empty" bundle:nil];
    //win.contentViewController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialController];
    [win showWindow:self];
    
        
        
    } else {
        //[self downer];
        NSInteger i = NSClosableWindowMask | NSTitledWindowMask | NSMiniaturizableWindowMask | NSResizableWindowMask;
        
        NSWindow *windo = [[NSWindow alloc] initWithContentRect:NSMakeRect(200, 200, 205,25) styleMask:i backing:NSBackingStoreBuffered defer:NO];
        //windo.titleVisibility = NSWindowTitleHidden;
        //windo.titlebarAppearsTransparent = YES;
        //windo.styleMask |= NSFullSizeContentViewWindowMask;
        NSWindowController *win = [[NSWindowController alloc] initWithWindow:windo];
        //[window shows]
        //NSViewController *view = [[NSViewController alloc] init];
        //windo.contentViewController = view;
        //NSView *view = [[NSView alloc] initW]
        ViewController *view = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateControllerWithIdentifier:@"Doi"];
        windo.title = @"Restrictions Cracker";
        win.contentViewController = view;
        [view doi];
        //[win.contentViewController loadView];
        //[win windowWillLoad];
        //[windo.contentView setAppearance:[NSAppearance appearanceNamed:@"neq"]];
        //win.contentViewController = [[NSViewController alloc] initWithNibName:@"Empty" bundle:nil];
        //win.contentViewController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialController];
        [win showWindow:self];
    }
    //[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"Done"];
    
}

-(BOOL)applicationShouldHandleReopen:(NSApplication *)sender hasVisibleWindows:(BOOL)flag {
    if (flag == YES) {
        return YES;
    } else {
        NSString *h = [NSString stringWithContentsOfFile:[[self applicationDirectoryPath] stringByAppendingString:@"/Text.txt"] encoding:NSUTF8StringEncoding error:NULL];
        if ([h isEqualToString:@"YES"] != YES) {
            NSInteger i = NSClosableWindowMask | NSTitledWindowMask | NSMiniaturizableWindowMask | NSResizableWindowMask;
            
            NSWindow *windo = [[NSWindow alloc] initWithContentRect:NSMakeRect(200, 200, 205,25) styleMask:i backing:NSBackingStoreBuffered defer:NO];
            //windo.titleVisibility = NSWindowTitleHidden;
            //windo.titlebarAppearsTransparent = YES;
            //windo.styleMask |= NSFullSizeContentViewWindowMask;
            NSWindowController *win = [[NSWindowController alloc] initWithWindow:windo];
            //[window shows]
            //NSViewController *view = [[NSViewController alloc] init];
            //windo.contentViewController = view;
            //NSView *view = [[NSView alloc] initW]
            ViewController *view = [[ViewController alloc] initWithNibName:@"ViewController2" bundle:nil];
            
            
            win.contentViewController = view;
            //[win windowWillLoad];
            //[windo.contentView setAppearance:[NSAppearance appearanceNamed:@"neq"]];
            //win.contentViewController = [[NSViewController alloc] initWithNibName:@"Empty" bundle:nil];
            //win.contentViewController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialController];
            [win showWindow:self];
            
            
            
        } else {
            
            NSInteger i = NSClosableWindowMask | NSTitledWindowMask | NSMiniaturizableWindowMask | NSResizableWindowMask;
            
            NSWindow *windo = [[NSWindow alloc] initWithContentRect:NSMakeRect(200, 200, 205,25) styleMask:i backing:NSBackingStoreBuffered defer:NO];
            //windo.titleVisibility = NSWindowTitleHidden;
            //windo.titlebarAppearsTransparent = YES;
            //windo.styleMask |= NSFullSizeContentViewWindowMask;
            NSWindowController *win = [[NSWindowController alloc] initWithWindow:windo];
            //[window shows]
            //NSViewController *view = [[NSViewController alloc] init];
            //windo.contentViewController = view;
            //NSView *view = [[NSView alloc] initW]
            ViewController *view = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateControllerWithIdentifier:@"Doi"];
            windo.title = @"Restrictions Cracker";
            win.contentViewController = view;
            [view doi];
            //[win.contentViewController loadView];
            //[win windowWillLoad];
            //[windo.contentView setAppearance:[NSAppearance appearanceNamed:@"neq"]];
            //win.contentViewController = [[NSViewController alloc] initWithNibName:@"Empty" bundle:nil];
            //win.contentViewController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialController];
            [win showWindow:self];
        }

    }
    return YES;
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

-(void)downer {
    NSString *string = [ShellTask executeShellCommandSynchronously:@"cpan install Crypt::PBKDF2"];
    [@"YES" writeToFile:[[self applicationDirectoryPath] stringByAppendingString:@"/Text.txt"] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    NSLog(@"%@",string);
    
}

-(void)startDownloader {
    //NSString *string = [ShellTask executeShellCommandSynchronously:@"cpan install Crypt::PBKDF2"];
    [self performSelectorInBackground:@selector(downer) withObject:nil];
    //[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"Done"];
    //NSLog(@"%@",string);
}

- (NSString*)applicationDirectoryPath {
    NSString* bundleID = [[NSBundle mainBundle] bundleIdentifier];
    NSFileManager*fm = [NSFileManager defaultManager];
    NSURL*    dirPath = nil;
    
    // Find the application support directory in the home directory.
    NSArray* appSupportDir = [fm URLsForDirectory:NSApplicationSupportDirectory
                                        inDomains:NSUserDomainMask];
    if ([appSupportDir count] > 0)
    {
        // Append the bundle ID to the URL for the
        // Application Support directory
        dirPath = [[appSupportDir objectAtIndex:0] URLByAppendingPathComponent:bundleID];
        
        // If the directory does not exist, this method creates it.
        // This method is only available in OS X v10.7 and iOS 5.0 or later.
        NSError*    theError = nil;
        if (![fm createDirectoryAtURL:dirPath withIntermediateDirectories:YES
                           attributes:nil error:&theError])
        {
            // Handle the error.
            
            return nil;
        }
    }
    
    return dirPath.path;
}


@end
